import { PublicKey } from "@solana/web3.js";
export const NETWORK = "devnet";
export const CREATOR_ADDRESS = "A8rgsJecHutEamvb7e8p1a14LQH3vGRPr796CDaESMeu";
export const MAX_MINTAMOUNT_PERTX = 5;
export const MAX_SUPPLY = 2500;
export const DEV_WALLET = "DH8ozTSc4ZxeHTw15MyLUGCdfytSBTSvYP4erXw1P8wk";
